﻿namespace AdminWebpage.Models
{
    public class TThuocJoinTLoaiThuoc
    {
        public string? MaLoai { get; set; }

        public string? TenLoai { get; set; }

        public string? Anh { get; set; }

        public int? sumTheoLoai { get; set; }
    }
}
